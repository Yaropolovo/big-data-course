import sys
from pyspark.sql import SparkSession
import pyspark.sql.functions as F

DEPLOYMENT = "yarn"

if DEPLOYMENT == "yarn":
    spark = SparkSession.builder \
                        .master("yarn") \
                        .appName("spark-course") \
                        .config("spark.driver.memory", "512m") \
                        .config("spark.driver.cores", "1") \
                        .config("spark.executor.instances", "3") \
                        .config("spark.executor.cores", "1") \
                        .config("spark.executor.memory", "1g") \
                        .config("spark.jars.packages", "com.datastax.spark:spark-cassandra-connector_2.11:2.4.3") \
                        .config("spark.cassandra.connection.host", "brain-node1") \
                        .getOrCreate()
elif DEPLOYMENT == "local":
    spark = SparkSession.builder \
                        .master("local[2]") \
                        .appName("spark-course") \
                        .config("spark.driver.memory", "512m") \
                        .config("spark.jars.packages", "com.datastax.spark:spark-cassandra-connector_2.11:2.4.3") \
                        .config("spark.cassandra.connection.host", "brain-node1") \
                        .getOrCreate()
else:
    raise NotImplementedError("Deployment {d} is not supported!".format(d=DEPLOYMENT))

sc = spark.sparkContext

movie_path = '/data/movielens/movies.csv'
df = spark.read.options(inferSchema="true", header="true") \
            .csv(path=movie_path, header=True)

df_cleaned = df \
    .withColumnRenamed('movieId', 'movieid') \
    .withColumn('title', F.trim(F.col('title'))) \
    .filter(~F.col('title').like('%(____-)')) \
    .filter(~F.col('title').like('%(____-____)')) \
    .filter(F.col('genres') != '(no genres listed)') \
    .withColumn('year', F.regexp_extract(F.col('title'), ".*\(((18|19|20)\d{2})\)", 1)) \
    .filter(F.col('year') != '') \
    .withColumn('year', F.col('year').cast('int')) \
    .withColumn('genres', F.split(F.col('genres'), '\|')) \
    .na.drop(how='any', subset=['movieId', 'title', 'year', 'genres'])

df_cleaned.write.format("org.apache.spark.sql.cassandra") \
            .options(keyspace=sys.argv[1], table='movies').mode("append").save()

spark.stop()